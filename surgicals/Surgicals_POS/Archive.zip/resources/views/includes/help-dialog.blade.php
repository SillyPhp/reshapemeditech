<div>
	<!-- main heading -->
	<div class="lw-section-heading-block">
        <h3 class="lw-header"><?=  __tr( 'Help' )  ?></h3>
    </div>
	<!-- /main heading -->



	<div class="lw-dotted-line"></div>   
		     
    <!-- /Action -->
    <div class="lw-form-actions">
        <button type="button" ng-click="manageCtrl.closeDialog()" class="lw-btn btn btn-default" title="<?= __tr('Cancel') ?>"><?= __tr('Cancel') ?></button>
    </div>
    <!-- /Action -->
</div>