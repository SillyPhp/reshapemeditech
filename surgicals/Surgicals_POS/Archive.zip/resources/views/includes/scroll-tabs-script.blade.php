<script type="text/javascript">
	$(document).ready(function() {
		$('.nav-tabs').scrollingTabs().on('ready.scrtabs', function() {
        	$('.tab-content').show();
      	});
	});
</script>