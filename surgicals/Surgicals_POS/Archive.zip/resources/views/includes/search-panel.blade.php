<div class="panel-default">
    <div class="panel-heading lw-black-color hidden-xs" style="display: none;">
       
    </div>
    <div class="list-group visible-xs">
      <a class="list-group-item  lw-sidebar-menu-toggle-btn" href data-toggle="offcanvas"><i class="sidebar icon"> </i> <i class="fa fa-bars"></i> <?=  __tr( 'Menu' )  ?></a>
    </div>
</div>