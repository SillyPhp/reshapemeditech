<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="error-template">
                <h1><?= __tr('Invalid Request....') ?></h1>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.error-template {padding: 40px 15px;text-align: center;}
</style>