<div class="lw-custom-page-jumbotron jumbotron">
    <div class="lw-error-404">

	    <div class="lw-error-code m-b-10 m-t-20">
	    	<i class="fa fa-check-square-o fa-1x lw-success"></i> @section('page-title',  __tr( 'Reset your password' ))
	    </div>

    	<h2 class="font-bold"><?=  __tr(" Forgot Password ")  ?></h2>

	    <div class="fa-1x">
	        <?=  __tr('We have sent password reset link to your email address..')  ?>
	    </div>

	</div>
	
</div>