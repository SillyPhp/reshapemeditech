<div class="lw-custom-page-jumbotron jumbotron">
    <div class="lw-error-404">

	    <div class="lw-error-code m-b-10 m-t-20">
	    	<i class="fa fa-check-square-o fa-1x lw-success"></i> @section('page-title',  __tr(' Change Email' ))
	    </div>

    	<h2 class="font-bold"><?=  __tr("Activate your account")  ?></h2>

	    <div class="fa-1x">
	        <?=  __tr('Almost finished... We need to confirm your email address. To complete the activation process, please click the link in the email we just sent you..')  ?>
	    </div>

	</div>
</div>