<?php
/*
* ProductEngineInterface.php - Interface file
*
* This file is part of the Product component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Product\Interfaces;

interface ProductEngineInterface
{
}
