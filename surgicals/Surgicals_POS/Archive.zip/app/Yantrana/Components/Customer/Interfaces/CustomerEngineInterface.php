<?php
/*
* CustomerEngineInterface.php - Interface file
*
* This file is part of the Customer component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Customer\Interfaces;

interface CustomerEngineInterface
{
}
