<?php
/*
* SuppliersRepositoryInterface.php - Interface file
*
* This file is part of the Suppliers component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Suppliers\Interfaces;

interface SuppliersRepositoryInterface
{
}
