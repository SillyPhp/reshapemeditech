<?php
/*
* InventoryEngineInterface.php - Interface file
*
* This file is part of the Inventory component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Inventory\Interfaces;

interface InventoryEngineInterface
{
}
