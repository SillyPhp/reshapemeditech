<?php
/*
* FileAttachmentEngineInterface.php - Interface file
*
* This file is part of the FileAttachment component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Media\Interfaces;

interface FileAttachmentEngineInterface
{
}
