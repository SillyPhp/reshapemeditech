<?php
/*
* ReportEngineInterface.php - Interface file
*
* This file is part of the Report component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Report\Interfaces;

interface ReportEngineInterface
{
}
