<?php
/*
* LocationEngineInterface.php - Interface file
*
* This file is part of the Location component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Location\Interfaces;

interface LocationEngineInterface
{
}
