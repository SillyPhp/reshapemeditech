<?php
/*
* CategoryEngineInterface.php - Interface file
*
* This file is part of the Category component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Category\Interfaces;

interface CategoryEngineInterface
{
}
