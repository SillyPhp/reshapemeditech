<?php
/*
* CategoryRepositoryInterface.php - Interface file
*
* This file is part of the Category component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Category\Interfaces;

interface CategoryRepositoryInterface
{
}
