<?php
/*
* TaxRepositoryInterface.php - Interface file
*
* This file is part of the Tax component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Tax\Interfaces;

interface TaxRepositoryInterface
{
}
