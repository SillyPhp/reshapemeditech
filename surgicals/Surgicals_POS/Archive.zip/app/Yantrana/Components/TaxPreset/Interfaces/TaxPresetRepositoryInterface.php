<?php
/*
* TaxPresetRepositoryInterface.php - Interface file
*
* This file is part of the TaxPreset component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\TaxPreset\Interfaces;

interface TaxPresetRepositoryInterface
{
}
