<?php

/*
* DashboardRepositoryBlueprint.php - Interface file
*
* This file is part of the Dashboard component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Dashboard\Blueprints;

interface DashboardRepositoryBlueprint
{
}
