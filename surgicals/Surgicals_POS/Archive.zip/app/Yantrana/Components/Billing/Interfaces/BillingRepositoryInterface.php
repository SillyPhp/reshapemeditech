<?php
/*
* BillingRepositoryInterface.php - Interface file
*
* This file is part of the Billing component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Billing\Interfaces;

interface BillingRepositoryInterface
{
}
