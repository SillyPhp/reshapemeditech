<?php
/*
* RolePermissionEngineInterface.php - Interface file
*
* This file is part of the RolePermission component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\User\Interfaces;

interface RolePermissionEngineInterface
{
}
