<?php
/*
* UserRepositoryBlueprint.php - Interface file
*
* This file is part of the User component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\User\Blueprints;

interface UserRepositoryBlueprint
{
}
