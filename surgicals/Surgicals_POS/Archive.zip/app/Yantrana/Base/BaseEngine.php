<?php

namespace App\Yantrana\Base;

/**
 * Base Engine
 *
 * base engine for Angulara applications
 *
 *--------------------------------------------------------------------------- */

use App\Yantrana\__Laraware\Core\CoreEngine;

abstract class BaseEngine extends CoreEngine
{
}
