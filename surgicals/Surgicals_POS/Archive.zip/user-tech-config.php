<?php
/*
    IF you want to change some settings in config/__tech.php then do not edit that file you should use this file.
    Then you should add those overwritten settings in the following array
*/
return [
    //@example
    /* character limit
    ------------------------------------------------------------------------- */
    // 'character_limit'  => 30,
];
