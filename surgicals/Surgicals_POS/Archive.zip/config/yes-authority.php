<?php
/*
 *  YesAuthority Configurations
 *
 *  This configuration file is part of YesAuthority
 *
 *------------------------------------------------------------------------------------------------*/
return [
    /* authority configurations
     *--------------------------------------------------------------------------------------------*/
    'custom_config_path' => app_path('Yantrana/Support/custom-yes-authority.php'),
];
